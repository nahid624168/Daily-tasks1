package com.studyapp

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val resumeTick = mutableStateOf(0)

class MainActivity : ComponentActivity() {
    override fun onResume() { super.onResume(); resumeTick.value += 1 }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF6C3FD8))) { App(this) } }
    }
}

@Composable
fun App(a: Activity) {
    var tab by remember { mutableStateOf(0) }
    val names = listOf("Tasks", "Goal", "Widgets")
    val icons = listOf("✅", "🎯", "🔲")
    Scaffold(bottomBar = {
        NavigationBar {
            names.forEachIndexed { i, n ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icons[i]) }, label = { Text(n) })
            }
        }
    }) { p ->
        Box(Modifier.padding(p).fillMaxSize().background(Color(0xFFF3EFFF))) {
            when (tab) { 0 -> Tasks(a); 1 -> Goal(a); else -> Widgets(a) }
        }
    }
}

@Composable
fun Tasks(a: Activity) {
    var off by remember { mutableStateOf(0) }
    val date = Store.date(off)
    var list by remember(resumeTick.value, off) { mutableStateOf(Store.load(a, date)) }
    var new by remember { mutableStateOf("") }
    var span by remember { mutableStateOf(1) }
    var streak by remember(resumeTick.value) { mutableStateOf(Store.streak(a)) }
    val pc = listOf(Color(0xFFD32F2F), Color(0xFFF57C00), Color(0xFF388E3C))
    val pn = listOf("High", "Medium", "Low")
    fun upd(l: List<Task>) { list = l; Store.save(a, l, date); streak = Store.streak(a) }
    val done = list.count { it.done }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                TextButton({ off-- }) { Text("◀") }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(Store.label(off), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (off != 0) TextButton({ off = 0 }) { Text("Back to today") }
                }
                TextButton({ off++ }) { Text("▶") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(progress = { if (list.isEmpty()) 0f else done / list.size.toFloat() }, modifier = Modifier.size(80.dp), strokeWidth = 8.dp)
                    Text("$done/${list.size}", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Daily Task", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(if (done == list.size && done > 0) "All done! 🎉" else "Keep going! 💪")
                    Text("🔥 $streak Day Streak", fontWeight = FontWeight.Bold)
                    Text("🎯 Goal: ${Store.goal(a)} tasks daily")
                }
            }
        }
        itemsIndexed(list) { i, t ->
            Card(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(t.done, { c -> upd(list.toMutableList().also { it[i] = t.copy(done = c) }) })
                    Text(t.title, Modifier.weight(1f), textDecoration = if (t.done) TextDecoration.LineThrough else null)
                    Text(pn[t.pri], color = pc[t.pri], fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        modifier = Modifier.clickable { upd(list.toMutableList().also { it[i] = t.copy(pri = (t.pri + 1) % 3) }) }.padding(8.dp))
                    IconButton({ upd(list.filterIndexed { j, _ -> j != i }) }) { Icon(Icons.Default.Delete, null) }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Koy din er jonno:")
                TextButton({ if (span > 1) span-- }) { Text("−") }
                Text("$span", fontWeight = FontWeight.Bold)
                TextButton({ if (span < 60) span++ }) { Text("+") }
                Text(if (span > 1) "(${Store.label(off)} theke)" else "")
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(new, { new = it }, Modifier.weight(1f), placeholder = { Text("Add task") })
                Spacer(Modifier.width(8.dp))
                Button({ if (new.isNotBlank()) { Store.addMany(a, new.trim(), 1, span, off); list = Store.load(a, date); new = "" } }) { Text("Add") }
            }
        }
    }
}

@Composable
fun Widgets(a: Activity) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Daily Task Widget", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        val canPin = android.os.Build.VERSION.SDK_INT >= 26
        Text(if (canPin) "Home screen e add korte nicher button chapo." else "Home screen e fanka jayga long-press koro → Widgets → Study App → Daily Task select koro.")
        if (canPin) Button({
            val m = AppWidgetManager.getInstance(a)
            if (m.isRequestPinAppWidgetSupported) m.requestPinAppWidget(ComponentName(a, TaskWidget::class.java), null, null)
        }) { Text("+ Add Widget") }
    }
}

@Composable
fun Goal(a: Activity) {
    var n by remember { mutableStateOf(Store.goal(a)) }
    var days by remember { mutableStateOf(Store.days(a)) }
    fun setD(d: Set<Int>) { days = d; Store.setDays(a, d) }
    val dn = listOf("S", "M", "T", "W", "T", "F", "S")
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Edit Goal", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Current Goal: $n Tasks Daily 🎯")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button({ if (n > 1) { n--; Store.setGoal(a, n) } }) { Text("−") }
            Text("$n", fontSize = 28.sp, modifier = Modifier.padding(horizontal = 24.dp))
            Button({ if (n < 20) { n++; Store.setGoal(a, n) } }) { Text("+") }
        }
        Text("Select Days", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ setD((1..7).toSet()) }) { Text("Everyday") }
            OutlinedButton({ setD(setOf(2, 3, 4, 5, 6)) }) { Text("Mon–Fri") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            dn.forEachIndexed { i, nm ->
                val d = i + 1
                val sel = d in days
                Button({ setD(if (sel && days.size > 1) days - d else days + d) }, Modifier.weight(1f),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sel) Color(0xFF6C3FD8) else Color.White,
                        contentColor = if (sel) Color.White else Color.Black)) { Text(nm) }
            }
        }
        Text("Chuti'r din e streak bhange na.")
    }
}
