package com.studyapp

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

/**
 * Deliberately uses only framework RemoteViews-supported widgets and basic
 * text updates. This avoids custom/unsupported view inflation on older and
 * vendor-modified launchers (Android 7 through current Android versions).
 */
class TaskWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id ->
            manager.updateAppWidget(id, build(context, id))
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TOGGLE -> {
                val index = intent.getIntExtra(EXTRA_INDEX, -1)
                val tasks = Store.load(context)
                if (index >= 0 && index < tasks.size) {
                    val updated = tasks.toMutableList()
                    updated[index] = updated[index].copy(done = !updated[index].done)
                    Store.save(context, updated)
                } else {
                    refresh(context)
                }
            }
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            AppWidgetManager.ACTION_APPWIDGET_UPDATE -> refresh(context)
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.studyapp.action.TOGGLE_TASK"
        private const val EXTRA_INDEX = "task_index"
        private val ROW_IDS = intArrayOf(R.id.r1, R.id.r2, R.id.r3, R.id.r4, R.id.r5)
        private val CHECK_IDS = intArrayOf(R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5)
        private val TITLE_IDS = intArrayOf(R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5)

        private fun immutableFlag(): Int = PendingIntent.FLAG_IMMUTABLE

        private fun build(context: Context, widgetId: Int): RemoteViews {
            val tasks = Store.load(context).take(5)
            val doneCount = tasks.count { it.done }
            val totalCount = tasks.size
            val allDone = totalCount > 0 && doneCount == totalCount
            val views = RemoteViews(context.packageName, R.layout.widget_task)

            views.setTextViewText(R.id.date, Store.label(0))
            views.setTextViewText(R.id.sub, if (allDone) "Great job!" else "Keep going!")
            views.setTextViewText(
                R.id.progress,
                if (totalCount == 0) "No tasks added today"
                else "$doneCount of $totalCount tasks completed"
            )
            views.setTextViewText(
                R.id.msg,
                when {
                    totalCount == 0 -> "Add your first task"
                    allDone -> "All tasks completed!"
                    doneCount == 0 -> "Let's get started!"
                    else -> "You're making progress!"
                }
            )

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val openPendingIntent = PendingIntent.getActivity(
                context,
                1000 + widgetId,
                openIntent,
                immutableFlag() or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.root, openPendingIntent)
            views.setOnClickPendingIntent(R.id.more, openPendingIntent)
            views.setOnClickPendingIntent(R.id.menu, openPendingIntent)

            for (index in ROW_IDS.indices) {
                val rowId = ROW_IDS[index]
                if (index < tasks.size) {
                    val task = tasks[index]
                    views.setViewVisibility(rowId, View.VISIBLE)
                    views.setTextViewText(CHECK_IDS[index], if (task.done) "✓" else "○")
                    views.setTextViewText(TITLE_IDS[index], task.title)

                    val toggleIntent = Intent(context, TaskWidget::class.java).apply {
                        action = ACTION_TOGGLE
                        putExtra(EXTRA_INDEX, index)
                        // Distinct data URI prevents PendingIntent collisions between rows.
                        data = android.net.Uri.parse("studyapp://widget/$widgetId/task/$index")
                    }
                    val togglePendingIntent = PendingIntent.getBroadcast(
                        context,
                        2000 + widgetId * 10 + index,
                        toggleIntent,
                        immutableFlag() or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    views.setOnClickPendingIntent(rowId, togglePendingIntent)
                } else if (index == 0 && tasks.isEmpty()) {
                    views.setViewVisibility(rowId, View.VISIBLE)
                    views.setTextViewText(CHECK_IDS[index], "+")
                    views.setTextViewText(TITLE_IDS[index], "Tap to add today's tasks")
                    views.setOnClickPendingIntent(rowId, openPendingIntent)
                } else {
                    views.setViewVisibility(rowId, View.GONE)
                }
            }
            return views
        }

        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, TaskWidget::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isNotEmpty()) {
                ids.forEach { id -> manager.updateAppWidget(id, build(context, id)) }
            }
        }
    }
}
