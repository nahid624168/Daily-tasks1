package com.studyapp

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.view.View
import android.widget.RemoteViews

class TaskWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, build(c)) }
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        when (i.action) {
            TOGGLE -> {
                val idx = i.getIntExtra("i", -1)
                val l = Store.load(c)
                if (idx in l.indices) Store.save(c, l.toMutableList().also { it[idx] = l[idx].copy(done = !l[idx].done) })
            }
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> refresh(c)
        }
    }

    companion object {
        const val TOGGLE = "com.studyapp.TOGGLE"
        private val RW = intArrayOf(R.id.r1, R.id.r2, R.id.r3, R.id.r4, R.id.r5)
        private val CB = intArrayOf(R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5)
        private val TX = intArrayOf(R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5)

        // gol progress ring (2/5 Done) bitmap e aka
        private fun ring(done: Int, total: Int): Bitmap {
            val s = 260
            val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b)
            val w = 28f
            val r = RectF(w / 2 + 4, w / 2 + 4, s - w / 2 - 4, s - w / 2 - 4)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND; color = 0xFFE3E0EC.toInt()
            }
            cv.drawArc(r, 0f, 360f, false, p)
            if (total > 0 && done > 0) { p.color = 0xFF6C3FD8.toInt(); cv.drawArc(r, -90f, 360f * done / total, false, p) }
            val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER; color = 0xFF1E1245.toInt(); typeface = Typeface.DEFAULT_BOLD; textSize = 74f
            }
            cv.drawText("$done/$total", s / 2f, s / 2f + 18f, t)
            t.typeface = Typeface.DEFAULT; t.textSize = 32f; t.color = 0xFF4A3F7A.toInt()
            cv.drawText("Done", s / 2f, s / 2f + 62f, t)
            return b
        }

        fun build(c: Context): RemoteViews {
            val t = Store.load(c)
            val d = t.count { it.done }
            val v = RemoteViews(c.packageName, R.layout.widget_task)
            val all = t.isNotEmpty() && d == t.size
            v.setTextViewText(R.id.date, Store.label(0))
            v.setTextViewText(R.id.sub, if (all) "Great job! 🎉" else "Keep going! 💪")
            v.setTextViewText(R.id.msg, if (t.isEmpty()) "No tasks today" else if (all) "All tasks done!" else if (d == 0) "Let's get started!" else "You're on track!")
            v.setTextViewText(R.id.msg2, if (all) "See you tomorrow." else "Complete more tasks today.")
            v.setImageViewBitmap(R.id.ring, ring(d, t.size))
            val open = PendingIntent.getActivity(c, 10, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            for (k in 0 until 5) {
                if (k < t.size) {
                    val x = t[k]
                    val s = SpannableString(x.title)
                    if (x.done) {
                        s.setSpan(ForegroundColorSpan(0xFF6B5FA0.toInt()), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        s.setSpan(StrikethroughSpan(), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    v.setTextViewText(TX[k], s)
                    v.setImageViewResource(CB[k], if (x.done) R.drawable.cb_on else R.drawable.cb_off)
                    v.setViewVisibility(RW[k], View.VISIBLE)
                    val tg = Intent(c, TaskWidget::class.java).setAction(TOGGLE).putExtra("i", k)
                    v.setOnClickPendingIntent(RW[k], PendingIntent.getBroadcast(c, k, tg, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                } else if (k == 0) {
                    v.setTextViewText(TX[0], "Tap to add today's tasks")
                    v.setImageViewResource(CB[0], R.drawable.cb_off)
                    v.setViewVisibility(RW[0], View.VISIBLE)
                    v.setOnClickPendingIntent(RW[0], open)
                } else v.setViewVisibility(RW[k], View.GONE)
            }
            v.setOnClickPendingIntent(R.id.root, open)
            v.setOnClickPendingIntent(R.id.more, open)
            v.setOnClickPendingIntent(R.id.menu, open)
            return v
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, TaskWidget::class.java)).forEach { m.updateAppWidget(it, build(c)) }
        }
    }
}
