package com.studyapp

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

// pri: 0 = High, 1 = Medium, 2 = Low
data class Task(val title: String, val done: Boolean, val pri: Int = 1)

object Store {
    private const val DEF = "Study English Grammar|0|0\nSolve 50 MCQ|0|1\nRead Bangla Literature|0|2\nMake Revision Note|0|0\nTake Mock Test|0|1"
    private fun p(c: Context) = c.getSharedPreferences("s", 0)

    private fun cal(off: Int): Calendar = Calendar.getInstance().also { it.add(Calendar.DAY_OF_YEAR, off) }
    fun date(off: Int = 0): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal(off).time)
    fun label(off: Int): String = SimpleDateFormat("d MMM, EEE", Locale.getDefault()).format(cal(off).time)
    private fun active(c: Context, off: Int) = cal(off).get(Calendar.DAY_OF_WEEK) in days(c)

    // Goal settings (days: 1 = Sun ... 7 = Sat)
    fun goal(c: Context) = p(c).getInt("goal", 5)
    fun setGoal(c: Context, n: Int) { p(c).edit().putInt("goal", n).apply() }
    fun days(c: Context): Set<Int> =
        (p(c).getString("days", "1,2,3,4,5,6,7") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toSet()
    fun setDays(c: Context, d: Set<Int>) { p(c).edit().putString("days", d.joinToString(",")).apply() }

    // protita tarikher alada task list ("d_yyyy-MM-dd")
    fun load(c: Context, d: String = date(0)): List<Task> {
        val dflt = if (d == date(0)) (p(c).getString("t", DEF) ?: DEF) else ""
        return (p(c).getString("d_$d", dflt) ?: "").split("\n").filter { it.contains("|") }.map {
            val x = it.split("|")
            Task(x[0], x[1] == "1", x.getOrNull(2)?.toIntOrNull() ?: 1)
        }
    }

    private fun put(c: Context, d: String, l: List<Task>) {
        val raw = l.joinToString("\n") {
            it.title.replace("|", " ").replace("\n", " ") + "|" + (if (it.done) 1 else 0) + "|" + it.pri
        }
        p(c).edit().putString("d_$d", raw).apply()
    }

    // ekshathe onek din e task add: startOff theke days ta din
    fun addMany(c: Context, title: String, pri: Int, days: Int, startOff: Int) {
        for (i in 0 until days) { val d = date(startOff + i); put(c, d, load(c, d) + Task(title, false, pri)) }
        TaskWidget.refresh(c)
    }

    private fun contiguous(c: Context): Boolean {
        val last = p(c).getString("last", "") ?: ""
        if (last.isEmpty()) return false
        for (o in -1 downTo -8) {
            if (date(o) == last) return true
            if (active(c, o)) return false
        }
        return false
    }

    fun streak(c: Context): Int =
        if (p(c).getString("last", "") == date(0) || contiguous(c)) p(c).getInt("streak", 0) else 0

    fun save(c: Context, l: List<Task>, d: String = date(0)) {
        put(c, d, l)
        val need = minOf(goal(c), l.size)
        if (d == date(0) && l.isNotEmpty() && l.count { it.done } >= need && p(c).getString("last", "") != date(0)) {
            val next = if (contiguous(c)) p(c).getInt("streak", 0) + 1 else 1
            p(c).edit().putInt("streak", next).putString("last", date(0)).apply()
        }
        TaskWidget.refresh(c)
    }
}
